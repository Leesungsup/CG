Most of these textures were taken from freepbr.com or https://opengameart.org/content/36-free-ground-textures-diffuse-normals.

They were all 2kx2k so they've been resaved as 1k.
All models are free from https://sketchfab.com/
